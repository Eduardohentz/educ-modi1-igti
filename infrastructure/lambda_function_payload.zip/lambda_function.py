import boto3

def handler(event, context):
    """
    Lambda function that starts a job flow in EMR
    """